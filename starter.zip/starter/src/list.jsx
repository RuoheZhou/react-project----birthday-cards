import Person from './person';

const List = ({people}) => {
    return <section>
{/* 循环 */}
        {people.map((p)=>{
            return <Person key={p.id} {...p}/>
        })}


    </section>;
};
export default List;